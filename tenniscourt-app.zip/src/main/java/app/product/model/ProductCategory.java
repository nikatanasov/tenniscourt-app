package app.product.model;

public enum ProductCategory {
    WATER, BALLS, ACCESSORY, RACQUETS, OTHER
}
