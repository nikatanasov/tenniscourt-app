package app.reviews.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

@Data
public class Review {

    private UUID courtId;

    private BigDecimal averageRating;

    private List<String> allComments;
}
