package app.reviews.client;

import app.reviews.dto.Review;
import app.reviews.dto.ReviewRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

@FeignClient(name = "rating-svc", url = "http://localhost:8082/api/v1/reviews")
public interface ReviewClient {

    @GetMapping
    ResponseEntity<List<Review>> getAllReviews();

    @PostMapping
    ResponseEntity<Void> upsertReviewForCourt(@RequestBody ReviewRequest reviewRequest);
}
