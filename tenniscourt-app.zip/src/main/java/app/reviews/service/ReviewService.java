package app.reviews.service;

import app.court.model.Court;
import app.court.service.CourtService;
import app.reviews.client.ReviewClient;
import app.reviews.dto.Review;
import app.reviews.dto.ReviewRequest;
import app.web.dto.NewReviewRequest;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class ReviewService {
    private final ReviewClient reviewClient;
    private final CourtService courtService;

    @Autowired
    public ReviewService(ReviewClient reviewClient, CourtService courtService) {
        this.reviewClient = reviewClient;
        this.courtService = courtService;
    }

    /*public List<Review> getAllReviews(){
        ResponseEntity<List<Review>> httpResponse = reviewClient.getAllReviews();
        return httpResponse.getBody();
    }

    public void postNewReview(NewReviewRequest newReviewRequest) {
        Court court = courtService.getCourtByName(newReviewRequest.getCourtName());
        ReviewRequest reviewRequest = ReviewRequest.builder()
                .courtId(court.getId())
                .rating(newReviewRequest.getRating())
                .comment(newReviewRequest.getComment())
                .username(newReviewRequest.getUsername())
                .build();
        ResponseEntity<Void> httpResponse = reviewClient.upsertReviewForCourt(reviewRequest);

        if(httpResponse.getStatusCode().is2xxSuccessful()){
            throw new RuntimeException("Failed to save review!");
        }
    }*/
}
