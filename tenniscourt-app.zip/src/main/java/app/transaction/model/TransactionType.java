package app.transaction.model;

public enum TransactionType {
    DEPOSIT, PRODUCT_PURCHASE, RESERVATION_PAYMENT, REFUND
}
