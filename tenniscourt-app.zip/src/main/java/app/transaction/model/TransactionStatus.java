package app.transaction.model;

public enum TransactionStatus {
    SUCCEEDED, FAILED
}
