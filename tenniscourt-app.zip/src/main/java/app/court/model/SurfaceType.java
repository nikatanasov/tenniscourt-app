package app.court.model;

public enum SurfaceType {
    CLAY, GRASS, HARD
}
