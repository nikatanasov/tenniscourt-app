package app.user.model;

public enum UserRole {
    ADMIN, USER
}
