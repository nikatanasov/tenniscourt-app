package app.reservation.model;

public enum ReservationStatus {
    CONFIRMED, CANCELLED, COMPLETED
}
