package app.web;

import app.cart.service.CartService;
import app.product.service.ProductService;
import app.security.AuthenticationMetadata;
import app.transaction.service.TransactionService;
import app.user.model.UserRole;
import app.user.service.UserService;
import app.wallet.service.WalletService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import java.util.UUID;

import static app.TestBuilder.aRandomUser;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ProductController.class)
public class ProductControllerApiTest {
    @MockitoBean
    private UserService userService;

    @MockitoBean
    private ProductService productService;

    @MockitoBean
    private TransactionService transactionService;

    @MockitoBean
    private CartService cartService;

    @MockitoBean
    private WalletService walletService;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void getRequestToAllProductsPage_ShouldReturnProductsListPage() throws Exception {
        when(userService.getById(any())).thenReturn(aRandomUser());
        MockHttpServletRequestBuilder request = get("/products")
                .with(user(new AuthenticationMetadata(UUID.randomUUID(), "Vik123", "123123", UserRole.USER, true)));

        mockMvc.perform(request)
                .andExpect(status().isOk())
                .andExpect(view().name("products-list"))
                .andExpect(model().attributeExists("products", "items"));

        verify(userService, times(1)).getById(any());
        verify(productService, times(1)).getAllProducts();
    }

    @Test
    void postRequestToProcessAddingNewProductForAdmin_happyPath() throws Exception {
        when(userService.getById(any())).thenReturn(aRandomUser());
        MockHttpServletRequestBuilder request = post("/products/add")
                .formField("name", "Water")
                .formField("price", "2.00")
                .formField("quantity", "1")
                .formField("imageUrl", "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQWeeOn0l5588g1qOi5xpcityQlvdQc5RYQsA&s")
                .formField("productCategory", "WATER")
                .with(user(new AuthenticationMetadata(UUID.randomUUID(), "Vik123", "123123", UserRole.ADMIN, true)))
                .with(csrf());

        mockMvc.perform(request)
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/home"));

        verify(userService, times(1)).getById(any());
        verify(productService, times(1)).addNewProduct(any());
    }
}
